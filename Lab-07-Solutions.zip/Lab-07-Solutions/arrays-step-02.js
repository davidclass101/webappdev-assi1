// EXERCISE 1

// Declare the following array

const programming = ['JavaScript', 'Python', 'Ruby', 'Java'];
console.log(programming);

// Create a new array modernProgramming, which combines programming with the array ['Haskell', 'Clojure']

const modernProgramming = programming.concat("Haskell", "Clojure");
console.log(modernProgramming);

// Return the string 'JavaScript, Python, Ruby, Java' by using join on the programming array

const programmingString = programming.join(", ");
console.log(programmingString);

// Use slice to take the first two elements of the modernProgramming array and save them into a variable called favouriteLanguages

const favouriteLanguages = modernProgramming.slice(0, 2);
console.log(modernProgramming);
console.log(favouriteLanguages);



// EXERCISE 2

// Declare the following array:

const names = ['Patrick', 'Mary', 'David', 'Patricia', 'Mary', 'Anne', 'Jack', 'Patrick', 'Siobhan', 'Catherine'];

// Use indexOf() to find the first occurence of the name 'Mary'

const maryIndex = names.indexOf("Mary")
console.log(maryIndex);
console.log(names[maryIndex]);


// Use lastIndexOf() to find the last occurence of the name 'Patrick'

const patrickIndex = names.lastIndexOf("Patrick");
console.log(patrickIndex);
console.log(names[patrickIndex]);

// Use findIndex() to find an array element with 8 or more letters

const index = names.findIndex(name => name.length >= 8);
console.log(index);
console.log(names[index]);

// Use filter() to return an array of any elements with 8 or more letters

const filteredNames = names.filter(name => name.length >= 8);
console.log(filteredNames);