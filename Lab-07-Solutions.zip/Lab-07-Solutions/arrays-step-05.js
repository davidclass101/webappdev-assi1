const playlistCollection = [
  {
    id: "01",
    title: "Beethoven Sonatas",
    songs: [
      {
        id: "04",
        title: "Piano Sonata No. 3",
        artist: "Beethoven",
      },
      {
        id: "05",
        title: "Piano Sonata No. 7",
        artist: "Beethoven",
      },
      {
        id: "06",
        title: "Piano Sonata No. 10",
        artist: "Beethoven",
      }
    ]
  },
  {
    id: "02",
    title: "Beethoven Concertos",
    songs: [
      {
        id: "07",
        title: "Piano Concerto No. 0",
        artist: "Beethoven",
      },
      {
        id: "08",
        title: "Piano Concerto No. 4",
        artist: "Beethoven",
      },
      {
        id: "09",
        title: "Piano Concerto No. 6",
        artist: "Beethoven",
      }
    ]
  },
  {
    id: "03",
    title: "Beethoven Variations",
    songs: [
      {
        id: "10",
        title: "Opus 34: Six variations on a theme in F major",
        artist: "Beethoven",
      },
      {
        id: "11",
        title: "Opus 120: Thirty-three variations on a waltz by Diabelli in C majo",
        artist: "Beethoven",
      }
    ]
  }
];

// EXERCISES:
// Try each of the following approaches to displaying the playlist data
// View the results in the console

// EXERCISE 1:
console.log("Playlist Collection")
console.log (playlistCollection);

// EXERCISE 2:
console.log("Each Playlist Element")
for (let i = 0; i < playlistCollection.length; i++) {
  console.log(playlistCollection[i]);
}

//OR
console.log("Using for of")
for (let playlist of playlistCollection) {
	console.log(playlist)
}

//OR
console.log("Using forEach")
playlistCollection.forEach(playlist => console.log(playlist))
	

// EXERCISE 3:
console.log("Each Playlist Title")
for (let i = 0; i < playlistCollection.length; i++) {
  console.log(playlistCollection[i].title)
}

//OR
console.log("Using for of")
for (let playlist of playlistCollection) {
	console.log(playlist.title)
}

//OR
console.log("Using forEach")
playlistCollection.forEach(playlist => console.log(playlist.title))

// EXERCISE 4A:
console.log("Each Playlist Title plus Songs")
for (let i = 0; i < playlistCollection.length; i++) {
  console.log(playlistCollection[i].title)
  for (let j=0; j < playlistCollection[i].songs.length; j++) {
    console.log(playlistCollection[i].songs[j]);
  }
}

//OR
console.log("Using for of")
for (let playlist of playlistCollection) {
	console.log(playlist.title)
	 for (let song of playlist.songs) {
		 console.log(song)
	 }
}

//OR
console.log("Using forEach")
playlistCollection.forEach(playlist => {
	console.log(playlist.title)
	playlist.songs.forEach(song => console.log(song))
})

// EXERCISE 4B:
console.log("Each Playlist Title plus Song Title and Artist")
for (let i = 0; i < playlistCollection.length; i++) {
  console.log(playlistCollection[i].title)
  for (let j=0; j < playlistCollection[i].songs.length; j++) {
    console.log(playlistCollection[i].songs[j].title);
    console.log(playlistCollection[i].songs[j].artist);
  }
}

//OR
console.log("Using for of")
for (let playlist of playlistCollection) {
	console.log(playlist.title)
	 for (let song of playlist.songs) {
		 console.log(song.title)
		 console.log(song.artist)
	 }
}

//OR
console.log("Using forEach")
playlistCollection.forEach(playlist => {
	console.log(playlist.title)
	playlist.songs.forEach(song => {
		console.log(song.title)
		console.log(song.artist)
	})
})


// EXERCISE 5A:
// Create a variable called numplaylists and use a single for loop to count the number of playlists. Log the result to the console.
console.log("Some Statistics")
let numplaylists = 0; 

for (let playlist of playlistCollection) {
  numplaylists++;
}

console.log(`There are ${numplaylists} playlists in the collection`);

// EXERCISE 5B:
// Create a variable called numplaylists2 to output the number of playlists using playlistCollection.length. Log the result to the console.

let numplaylists2 = playlistCollection.length;
console.log(`There are ${numplaylists2} playlists in the collection`);

// EXERCISE 5C:
// Create a variable called numsongs and use a nested for loop to count the number of songs. Log the result to the console.

let numsongs = 0;

for (let playlist of playlistCollection) {
    for (let song of playlist.songs) {
      numsongs++;
  }
}

console.log(`There are ${numsongs} songs in the collection`);

/* EXERCISE 5D:
Create a variable called numsongs2 and use a for loop (iterating through the playlists) 
to count the number of songs using songs.length. Log the result to the console.
*/

let numsongs2 = 0;

for (let playlist of playlistCollection) {
     numsongs2 += playlist.songs.length
}

console.log(`There are ${numsongs2} songs in the collection`);
