// Introduce this array:

const people = ['Greg', 'Mary', 'Devon', 'James'];

// Using a for..of loop, iterate through this array and console.log all of the people

for(let name of people){
    console.log(name);
}

// Again using for a loop, iterate in the reverse direction, logging the people starting at 'James' and finishing with 'Greg'

for(let i = people.length - 1; i >= 0; i--){
    console.log(people[i]);
}