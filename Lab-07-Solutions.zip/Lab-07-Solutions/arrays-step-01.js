// Create an array of your favourite foods (call it favouriteFoods).
//Make sure it has at least three elements.

const favouriteFoods = ["Pizza", "Curry", "Chips"];
console.log(favouriteFoods);

// Access the second element in favouriteFoods

console.log(favouriteFoods[1]);

// Change the last element in favouriteFoods to some other food

favouriteFoods[2] = "Bread";
console.log(favouriteFoods);

// Remove the first element in favouriteFoods and store it in a variable called formerFavouriteFood

formerFavouriteFood = favouriteFoods.shift();
console.log(favouriteFoods);
console.log(formerFavouriteFood);

// Add a favourite food to the back of the favouriteFoods array

favouriteFoods.push("Cheese");
console.log(favouriteFoods);

// Add a favourite food to the front of the favouriteFoods array

favouriteFoods.unshift("Chocolate");
console.log(favouriteFoods);

// RemoveRemove the last element in the array and save it in a variable called lastFavouriteFood. Log the lastFavouriteFood variable to the console.

lastFavouriteFood = favouriteFoods.pop();
console.log(favouriteFoods);
console.log(lastFavouriteFood);