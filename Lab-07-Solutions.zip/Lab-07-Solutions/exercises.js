const playlistCollection = [
  {
    id: "01",
    title: "Beethoven Sonatas",
    songs: [
      {
        id: "04",
        title: "Piano Sonata No. 3",
        artist: "Beethoven",
      },
      {
        id: "05",
        title: "Piano Sonata No. 7",
        artist: "Beethoven",
      },
      {
        id: "06",
        title: "Piano Sonata No. 10",
        artist: "Beethoven",
      }
    ]
  },
  {
    id: "02",
    title: "Beethoven Concertos",
    songs: [
      {
        id: "07",
        title: "Piano Concerto No. 0",
        artist: "Beethoven",
      },
      {
        id: "08",
        title: "Piano Concerto No. 4",
        artist: "Beethoven",
      },
      {
        id: "09",
        title: "Piano Concerto No. 6",
        artist: "Beethoven",
      }
    ]
  },
  {
    id: "03",
    title: "Beethoven Variations",
    songs: [
      {
        id: "10",
        title: "Opus 34: Six variations on a theme in F major",
        artist: "Beethoven",
      },
      {
        id: "11",
        title: "Opus 120: Thirty-three variations on a waltz by Diabelli in C major",
        artist: "Beethoven",
      }
    ]
  },
  {
    id: "04",
    title: "Beethoven Symphonies",
    songs: [
      {
        id: "12",
        title: "Opus 21: Symphony No. 1 in C major",
        artist: "Beethoven",
      },
      {
        id: "13",
        title: "Opus 36: Symphony No. 2 in D major",
        artist: "Beethoven",
      },
       {
        id: "14",
        title: "Opus 55: Symphony No. 3 in E flat major",
        artist: "Beethoven",
      },
              {
        id: "15",
        title: "Opus 60: Symphony No. 4 in B flat major",
        artist: "Beethoven",
      }
    ]
  }
];

// EXERCISES:

// EXERCISE 1: Find the average number of songs across all the playlists and log this to the console

let numplaylists = playlistCollection.length

let numsongs = 0;


for (let playlist of playlistCollection) {
     numsongs += playlist.songs.length
}

/*
You can also use forEach:
playlistCollection.forEach(playlist => numsongs +=playlist.songs.length);
*/

let average = numsongs/numplaylists

console.log(`On average, there are ${average} songs in each playlist`);


// EXERCISE 2: Find the playlist with the most songs and log this to the console

let currentLargest = 0;
let largestPlaylistTitle = "";

for (playlist of playlistCollection) {
    
    if(playlist.songs.length > currentLargest){
        currentLargest = playlist.songs.length;
        largestPlaylistTitle = playlist.title;
    }
       
}

console.log(`The playlist with the most songs is ${largestPlaylistTitle}; it has ${currentLargest} songs`);


// EXERCISE 3: Find the playlist with the least songs and log this to the console

let currentSmallest = playlistCollection[0].songs.length;
let smallestPlaylistTitle = playlistCollection[0].title;

for (playlist of playlistCollection) {
    
    if(playlist.songs.length < currentSmallest){
        currentSmallest = playlist.songs.length;
        smallestPlaylistTitle = playlist.title;
    }
       
}

console.log(`The playlist with the least songs is ${smallestPlaylistTitle}; it has ${currentSmallest} songs`);